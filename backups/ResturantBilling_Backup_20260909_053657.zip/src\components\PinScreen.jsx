import { useState, useCallback, useEffect } from 'react';
import { isPinSet, setPin, verifyPin } from '../utils/pin';
import { playKeyPress, playButtonPress, playErrorSound, playCheckoutSuccess } from '../utils/audio';

export default function PinScreen({ onUnlock }) {
  const [mode, setMode] = useState('loading'); // loading, verify, setup, confirm, role-select
  const [pin, setPinInput] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);
  const [authenticatedRole, setAuthenticatedRole] = useState('owner');

  useEffect(() => {
    isPinSet().then((set) => {
      setMode(set ? 'verify' : 'setup');
    });
  }, []);

  const triggerShake = useCallback(() => {
    setShake(true);
    playErrorSound();
    setTimeout(() => setShake(false), 500);
  }, []);

  const handleDigit = useCallback((digit) => {
    playKeyPress();
    if (mode === 'setup') {
      setPinInput((prev) => {
        const next = prev + digit;
        if (next.length === 4) {
          setTimeout(() => setMode('confirm'), 200);
        }
        return next.length <= 4 ? next : prev;
      });
    } else if (mode === 'confirm') {
      setConfirmPin((prev) => {
        const next = prev + digit;
        if (next.length === 4) {
          setTimeout(() => {
            if (pin === next) {
              setPin(pin).then(() => {
                playCheckoutSuccess();
                setAuthenticatedRole('owner');
                setTimeout(() => setMode('role-select'), 500);
              });
            } else {
              setError('PINs do not match! Try again');
              triggerShake();
              setTimeout(() => {
                setPinInput('');
                setConfirmPin('');
                setError('');
                setMode('setup');
              }, 1500);
            }
          }, 200);
        }
        return next.length <= 4 ? next : prev;
      });
    } else if (mode === 'verify') {
      setPinInput((prev) => {
        const next = prev + digit;
        if (next.length === 4) {
          setTimeout(() => {
            verifyPin(next).then((result) => {
              const isValid = typeof result === 'object' ? result.valid : result;
              const role = typeof result === 'object' && result.role ? result.role : 'owner';

              if (isValid) {
                playCheckoutSuccess();
                setAuthenticatedRole(role);
                setTimeout(() => setMode('role-select'), 500);
              } else {
                setError('Wrong PIN!');
                triggerShake();
                setTimeout(() => {
                  setPinInput('');
                  setError('');
                }, 1200);
              }
            });
          }, 200);
        }
        return next.length <= 4 ? next : prev;
      });
    }
  }, [mode, pin, triggerShake]);

  const handleBackspace = useCallback(() => {
    playButtonPress();
    if (mode === 'confirm') {
      setConfirmPin((prev) => prev.slice(0, -1));
    } else if (mode === 'verify') {
      setPinInput((prev) => prev.slice(0, -1));
    }
  }, [mode]);

  if (mode === 'loading') {
    return (
      <div className="h-full flex items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800">
        <div className="text-2xl animate-pulse text-white">Loading...</div>
      </div>
    );
  }

  if (mode === 'role-select') {
    const showOwner = authenticatedRole === 'owner';
    const showManager = authenticatedRole === 'owner' || authenticatedRole === 'manager';
    const showCashier = true;

    return (
      <div className="h-full flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800 p-6 animate-fade-in">
        <div className="text-6xl mb-3 text-blue-500">👤</div>
        <h1 className="text-3xl font-bold text-white mb-2">Select Your Role</h1>
        <p className="text-gray-400 text-sm mb-8">Choose who is using the POS right now</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 w-full max-w-3xl">
          {showOwner && (
            <button
              onClick={() => { playButtonPress(); onUnlock('owner'); }}
              className="p-6 rounded-3xl bg-gradient-to-br from-amber-600 to-orange-700 text-white flex flex-col items-center gap-3 shadow-xl hover:scale-105 transition-all btn-press"
            >
              <span className="text-5xl">👔</span>
              <span className="text-2xl font-bold">Owner</span>
              <span className="text-amber-200 text-xs font-medium bg-black/20 px-3 py-1 rounded-full">Full Access</span>
            </button>
          )}

          {showManager && (
            <button
              onClick={() => { playButtonPress(); onUnlock('manager'); }}
              className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex flex-col items-center gap-3 shadow-xl hover:scale-105 transition-all btn-press"
            >
              <span className="text-5xl">📋</span>
              <span className="text-2xl font-bold">Manager</span>
              <span className="text-emerald-200 text-xs font-medium bg-black/20 px-3 py-1 rounded-full">Operations</span>
            </button>
          )}

          {showCashier && (
            <button
              onClick={() => { playButtonPress(); onUnlock('cashier'); }}
              className="p-6 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex flex-col items-center gap-3 shadow-xl hover:scale-105 transition-all btn-press"
            >
              <span className="text-5xl">💵</span>
              <span className="text-2xl font-bold">Cashier</span>
              <span className="text-blue-200 text-xs font-medium bg-black/20 px-3 py-1 rounded-full">Billing Only</span>
            </button>
          )}
        </div>

        <button
          onClick={() => {
            playButtonPress();
            setPinInput('');
            setMode('verify');
          }}
          className="mt-8 text-gray-400 text-sm hover:text-white transition-colors"
        >
          ← Back to PIN
        </button>
      </div>
    );
  }

  const currentPin = mode === 'confirm' ? confirmPin : pin;
  const title = mode === 'setup' ? 'Set Your PIN'
    : mode === 'confirm' ? 'Confirm PIN'
    : 'Enter PIN';
  const subtitle = mode === 'setup' ? 'Choose a 4-digit PIN'
    : mode === 'confirm' ? 'Re-enter your PIN'
    : 'Enter your 4-digit PIN';

  const digits = [1, 2, 3, 4, 5, 6, 7, 8, 9, null, 0, 'back'];

  return (
    <div className="h-full flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800 animate-fade-in">
      <div className="text-6xl mb-4">🔒</div>
      <h1 className="text-3xl font-bold text-white mb-2">{title}</h1>
      <p className="text-gray-400 text-lg mb-8">{subtitle}</p>

      <div className={`flex gap-4 mb-4 ${shake ? 'animate-shake' : ''}`}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={`w-14 h-14 rounded-full border-3 flex items-center justify-center transition-all duration-200 ${
              currentPin.length > i
                ? mode === 'confirm' && pin !== confirmPin && currentPin.length === 4
                  ? 'border-red-500 bg-red-500/30'
                  : 'border-green-400 bg-green-400/30'
                : 'border-gray-600 bg-gray-800/50'
            }`}
          >
            {currentPin.length > i && (
              <div className="w-5 h-5 rounded-full bg-white" />
            )}
          </div>
        ))}
      </div>

      {error && (
        <div className="text-red-400 text-xl font-bold mb-4 animate-shake">
          {error}
        </div>
      )}

      <div className="grid grid-cols-3 gap-4 mt-4">
        {digits.map((d, idx) => {
          if (d === null) return <div key={idx} />;
          if (d === 'back') {
            return (
              <button
                key={idx}
                onClick={handleBackspace}
                className="w-20 h-20 rounded-2xl bg-gray-700/60 text-white text-2xl 
                  flex items-center justify-center btn-press active:bg-gray-600 
                  transition-colors hover:bg-gray-600/80"
              >
                ⌫
              </button>
            );
          }
          return (
            <button
              key={idx}
              onClick={() => handleDigit(d)}
              className="w-20 h-20 rounded-2xl bg-gradient-to-b from-gray-600 to-gray-700 
                text-white text-3xl font-bold flex items-center justify-center btn-press
                active:from-gray-500 active:to-gray-600 hover:from-gray-500 hover:to-gray-600
                transition-all shadow-lg"
            >
              {d}
            </button>
          );
        })}
      </div>

      {mode === 'setup' && (
        <button
          onClick={() => {
            playButtonPress();
            setAuthenticatedRole('owner');
            setMode('role-select');
          }}
          className="mt-8 text-gray-500 text-lg hover:text-gray-300 transition-colors"
        >
          Skip PIN Setup →
        </button>
      )}
    </div>
  );
}